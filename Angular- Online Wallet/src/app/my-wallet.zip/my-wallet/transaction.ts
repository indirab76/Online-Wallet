export class Transaction
{
    dateOfTransaction:Date;
    receiverId:number;
    senderId:number;
    amount:number;
    transactionId:number;
}
